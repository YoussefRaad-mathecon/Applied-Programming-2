#include "Student.hpp"

// **************** Exercise 7.1.1-2 ***********************

Student::Student() : name(""), library_fines(0.0), tuition_fees(0.0) {
    
}

Student::Student(std::string name, double fines, double fees) : name(name), tuition_fees(fees) {
    SetLibraryFines(fines);
}

// Secures that library fines are nonnegative
void Student::SetLibraryFines(double amount) {
    if (amount >= 0) {
        library_fines = amount;
    } else {
        // Whenever amount < 0
        std::cerr << "Error: Library fines must be nonnegative!" << std::endl;
    }
}

// Method to access library fines
double Student::GetLibraryFines() const {
    return library_fines;
}

// Method that returns the total money owed by the
// student, that is, the sum of the library fines
// and tuition fees associated with a given student
double Student::MoneyOwed() const {
    return tuition_fees + library_fines;
}
