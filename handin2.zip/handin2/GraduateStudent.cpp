#include "GraduateStudent.hpp"

// **************** Exercise 7.1.3-4 ***********************

GraduateStudent::GraduateStudent() : Student(), fullTime(true) {}

// Graduate students may be full-time students or part-time students
// Class of graduate students from the class of students written before
// with an additional member variable that stores whether the student
// is full-time or part-time

GraduateStudent::GraduateStudent(std::string name, double fines, double fees, bool fullTime) 
    : Student(name, fines, fees), fullTime(fullTime) {}

// Method that calculates the total money owed by a graduate student
// Requires the method for calculating the total money owed to
// be a virtual function of the parent class
double GraduateStudent::MoneyOwed() const {
    // Graduate students do not pay tuition fees
    return GetLibraryFines();
}
