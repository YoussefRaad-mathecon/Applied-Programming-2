#include "PhdStudent.hpp"

// **************** Exercise 7.1.5 ***********************

// Class of Ph.D. students from the class of Graduate students
PhdStudent::PhdStudent(std::string name, double fines, double fees, bool fullTime)
    : GraduateStudent(name, fines, fees, fullTime) {}

// Method that calculates the total money owed by a Ph.D. student
double PhdStudent::MoneyOwed() const {
    // Graduate students do not pay tuition fees
    // Ph.D. students are a special class of graduate
    // students who do not pay library fines
    return 0.0;
}


