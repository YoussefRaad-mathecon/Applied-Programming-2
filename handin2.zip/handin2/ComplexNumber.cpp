#include "ComplexNumber.hpp"
#include <cmath>



// Override default constructor
// Set real and imaginary parts to zero
ComplexNumber::ComplexNumber()
{
    mRealPart = 0.0;
    mImaginaryPart = 0.0;
}

// Constructor that sets complex number z=x+iy
ComplexNumber::ComplexNumber(double x, double y)
{
    mRealPart = x;
    mImaginaryPart = y;
}


// Method for computing the modulus of a complex number
double ComplexNumber::CalculateModulus() const
{
    return sqrt(mRealPart * mRealPart + mImaginaryPart * mImaginaryPart);
}

// Method for computing the argument of a complex number
double ComplexNumber::CalculateArgument() const
{
    return atan2(mImaginaryPart, mRealPart);
}

// Method for raising complex number to the power n 
// using De Moivre’s theorem - first complex 
// number must be converted to polar form
ComplexNumber ComplexNumber::CalculatePower(double n) const // Note that returned type is  ComplexNumber
{
    // Complex number must be converted to polar form first
    double modulus = CalculateModulus(); // Call methods from within the class.
    double argument = CalculateArgument();
    double mod_of_result = pow(modulus, n);
    double arg_of_result = argument * n;
    double real_part = mod_of_result * cos(arg_of_result);
    double imag_part = mod_of_result * sin(arg_of_result);
    ComplexNumber z(real_part, imag_part);
    return z;
}



// Overloading the = (assignment) operator
ComplexNumber &ComplexNumber::operator=(const ComplexNumber& z)
{
    mRealPart = z.mRealPart;
    mImaginaryPart = z.mImaginaryPart;
    /* Every object in C++ has access to its own address through a this pointer. Only member functions have a this pointer. */
    return *this; // Returning an object i.e., *this returns a reference to the object.
}

// Overloading the unary - operator
ComplexNumber ComplexNumber::operator-() const // The original complex number is left unchanged (through use of const)
{
    ComplexNumber w;
    w.mRealPart = mRealPart;
    w.mImaginaryPart = mImaginaryPart;
    return w;
}


// Overloading the binary + operator
ComplexNumber ComplexNumber::operator+(const ComplexNumber& z) const
{
    ComplexNumber w;
    w.mRealPart = mRealPart + z.mRealPart;
    w.mImaginaryPart = mImaginaryPart + z.mImaginaryPart;
    return w;
}

// Overloading the binary - operator
ComplexNumber ComplexNumber::operator-(const ComplexNumber& z) const
{
    ComplexNumber w;
    w.mRealPart = mRealPart - z.mRealPart;
    w.mImaginaryPart = mImaginaryPart - z.mImaginaryPart;
    return w;
}

// Overloading the output stream insertion << operator
std::ostream &operator<<(std::ostream& output, const ComplexNumber& z) // External function, not member method
{
    // Format as "(a + bi)" or as "(a - bi)"
    output << "(" << z.mRealPart << " ";
    if (z.mImaginaryPart >= 0.0)
    {
        output << "+ " << z.mImaginaryPart << "i)";
    }
    else
    {
        // z.mImaginaryPart < 0.0
        // Replace + with minus sign
        output << "- " << -z.mImaginaryPart << "i)";
    }
    return output;
}

// *******************************************************
// *********************EXERCISE**************************
// *******************************************************


// **************** Exercise 6.1.1 ***********************

// Method for accessing the real part of the complex 
// number using a member function
double ComplexNumber::GetRealPart() const
{
    return mRealPart;
}



// Method for accessing the imaginary part of the complex
// number using a member function
double ComplexNumber::GetImaginaryPart() const
{
    return mImaginaryPart;
}


// **************** Exercise 6.1.2 ***********************

// Method for accessing the real part of the complex 
// number by friend function
double RealPart(const ComplexNumber& z)
{
    return z.mRealPart;
}

// Method for accessing the imaginary part of the complex
// number by friend function
double ImaginaryPart(const ComplexNumber& z)
{
   return z.mImaginaryPart;
}


// **************** Exercise 6.1.3 ***********************

// Method for constructing a overridden copy constructor
ComplexNumber::ComplexNumber(const ComplexNumber& z)
{
    mRealPart = z.mRealPart;
    mImaginaryPart = z. mImaginaryPart;
}


// *****************Exercise 6.1.4************************

// A constructor that allows us to specify a real number in complex form through
// a constructor that accepts one double precision floating point variable as input, 
// sets the real part of the complex number to the input variable, 
// and the imaginary part to zero

ComplexNumber::ComplexNumber(double real)
{
    mRealPart = real;
    mImaginaryPart = 0.0;
}



// **************** Exercise 6.1.5 ***********************

// A 'const' method 'CalculateConjugate' which returns the
// complex conjugate 'x - iy' of a complex number 'x + iy'

ComplexNumber ComplexNumber::CalculateConjugate() const
{
    return ComplexNumber(mRealPart, -mImaginaryPart);
}


// **************** Exercise 6.1.6 ***********************
// A method 'SetToConjugate' which has a void return
// type and sets the complex number 'x + iy' to its
// complex conjugate 'x - iy'

void ComplexNumber::SetConjugate()
{
    mImaginaryPart = -mImaginaryPart;
}


// Not mandatory, but useful for exercise 6.1.7
ComplexNumber ComplexNumber::operator*(const ComplexNumber& z) const
{
	ComplexNumber y;
	y.mRealPart = (mRealPart*z.mRealPart) - (mImaginaryPart*z.mImaginaryPart);
	y.mImaginaryPart = (mRealPart*z.mImaginaryPart) + (mImaginaryPart*z.mRealPart);
	return y;
}





