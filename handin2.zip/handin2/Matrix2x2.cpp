
#include "Matrix2x2.hpp"

// **************** Exercise 6.2.1 ***********************

// An overridden default constructor that initialises all 
// entries of the matrix to zero
Matrix2x2::Matrix2x2() : val00(0.0), val01(0.0), val10(0.0), val11(0.0) {

}

// **************** Exercise 6.2.2 ***********************

// An overridden copy constructor
Matrix2x2::Matrix2x2(const Matrix2x2& other) : val00(other.val00), val01(other.val01), val10(other.val10), val11(other.val11) {

}

// **************** Exercise 6.2.3 ***********************

// A constructor that specifies the four entries of the
// matrix and allocates these entries appropriately
Matrix2x2::Matrix2x2(double a, double b, double c, double d) : val00(a), val01(b), val10(c), val11(d) {

}

// **************** Exercise 6.2.4 ***********************

// A method (function) that returns the determinant of the matrix
double Matrix2x2::CalcDeterminant() const 
{
    return val00 * val11 - val01 * val10;
}

// **************** Exercise 6.2.5 ***********************

// A method that returns the inverse of the matrix, if it exists
Matrix2x2 Matrix2x2::CalcInverse() const 
{
    double determinant = CalcDeterminant();
    return Matrix2x2(val11 / determinant, -val01 / determinant, -val10 / determinant, val00 / determinant);
}

// **************** Exercise 6.2.6 ***********************

// Overloading of the assignment operator, allowing us to
// write code such as 'A = B'; for instances of the class A and B
Matrix2x2& Matrix2x2::operator=(const Matrix2x2& other) 
{
    if (this != &other) {
        val00 = other.val00;
        val01 = other.val01;
        val10 = other.val10;
        val11 = other.val11;
    }
    return *this;
}

// **************** Exercise 6.2.7 ***********************

// Overloading of the unary subtraction operator, allowing
// us to write code such as 'A = -B';
// for instances of the class A and B
Matrix2x2 Matrix2x2::operator-() const 
{
    return Matrix2x2(-val00, -val01, -val10, -val11);
}

// **************** Exercise 6.2.8 ***********************

// Overloading of the binary addition and subtraction
// operators, allowing us to write code such as
// 'A = B + C'; or 'A = B - C';
// for instances of the class A, B and C
Matrix2x2 Matrix2x2::operator+(const Matrix2x2& z) const 
{
    return Matrix2x2(val00 + z.val00, val01 + z.val01, val10 + z.val10, val11 + z.val11);
}

Matrix2x2 Matrix2x2::operator-(const Matrix2x2& z) const 
{
    return Matrix2x2(val00 - z.val00, val01 - z.val01, val10 - z.val10, val11 - z.val11);
}

// **************** Exercise 6.2.9 ***********************

// A method that multiplies a matrix by a specified
// double precision floating point variable
void Matrix2x2::MultScalar(double scalar) 
{
    val00 *= scalar;
    val01 *= scalar;
    val10 *= scalar;
    val11 *= scalar;
}
